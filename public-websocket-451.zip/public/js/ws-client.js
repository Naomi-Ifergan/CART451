window.onload = function () {
  console.log("client js loaded in ws example");
 }